const ROOT_URL="index.php";
const ANIMATION_DURATION=1000;
let classNameAnimationIn="fade-in-down";
let classNameAnimationOut="fade-out-up";

$(function(){
	show();
	clickRootLink();
	clickReloadLink();
});

function show(){
	window.scrollTo(0, 0);
	$(".animate").attr("class", classNameAnimationIn);
	setTimeout(function(){
		$("."+classNameAnimationIn).attr("class", "show");
	}, ANIMATION_DURATION);
}

function clickRootLink(){
	$(document).on("click", ".root-link", function(event){
		event.preventDefault();
		executeLink(ROOT_URL, ".");
	});
}

function clickReloadLink(){
	$(document).on("click", ".reload-link", function(event){
		event.preventDefault();
		const url=$(this).attr("href");
		executeLink(url, url);
	});
}

function executeLink(loadUrl, historyUrl){
	if($(".show").length==1){
		$(".show").attr("class", classNameAnimationOut);
		setTimeout(function(){
			$("."+classNameAnimationOut).attr("class", "animate");
		}, ANIMATION_DURATION-10);
	}
	else ANIMATION_DURATION=0;
	setTimeout(function(){
		$("#no-reload").load(loadUrl+" #no-reload>*", show);
		history.pushState({url: historyUrl}, "", historyUrl);
	}, ANIMATION_DURATION);
}